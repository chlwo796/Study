package javaMid1.ch07;

public class P {
	private String phone;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void printMM() {
		System.out.println(getPhone());
	}

}