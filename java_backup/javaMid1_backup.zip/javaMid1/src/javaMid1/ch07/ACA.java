package javaMid1.ch07;

public class ACA extends AC {

}
