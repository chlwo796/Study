package javaMid1.ch07;

public class ExtendsEx02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ACAAA acaaa = new ACAAA();
//		System.out.println(acaaa.getA1());
//		System.out.println(acaaa.getA4());
		acaaa.printACAAA();
		AAB aab = new AAB();
//		System.out.println(aab.getA1());
//		System.out.println(aab.getA2());
//		System.out.println(aab.getA3());
		aab.printAAB();

	}

}
