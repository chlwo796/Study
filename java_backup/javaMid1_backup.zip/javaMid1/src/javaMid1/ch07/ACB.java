package javaMid1.ch07;

public class ACB extends AC{

}
