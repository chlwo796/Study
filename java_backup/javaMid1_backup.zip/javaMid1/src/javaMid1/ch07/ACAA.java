package javaMid1.ch07;

public class ACAA extends ACA{
	private int a4 = 100;

	public int getA4() {
		return a4;
	}

	public void setA4(int a4) {
		this.a4 = a4;
	}

}
