package javaMid1.ch07;

public class AAA extends AA{

}
