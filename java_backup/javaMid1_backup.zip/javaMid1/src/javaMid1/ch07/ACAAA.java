package javaMid1.ch07;

public class ACAAA extends ACAA{
	public void printACAAA() {
		System.out.println(getA1());
		System.out.println(getA4());
	}
}
