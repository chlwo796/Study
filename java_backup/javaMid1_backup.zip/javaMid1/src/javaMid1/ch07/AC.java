package javaMid1.ch07;

public class AC extends PP{

}
