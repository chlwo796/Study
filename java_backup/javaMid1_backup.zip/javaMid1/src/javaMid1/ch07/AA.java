package javaMid1.ch07;

public class AA extends PP{
	private int a2 = 8;

	public int getA2() {
		return a2;
	}

	public void setA2(int a2) {
		this.a2 = a2;
	}
}
