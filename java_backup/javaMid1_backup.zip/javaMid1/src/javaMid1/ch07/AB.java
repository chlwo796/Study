package javaMid1.ch07;

public class AB extends PP{

}
