package javaMid3.ex07;

public class Tire {
	public void roll() {
		System.out.println("roll");
	}
}
