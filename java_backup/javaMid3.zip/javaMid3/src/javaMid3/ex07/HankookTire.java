package javaMid3.ex07;

public class HankookTire extends Tire {

	@Override
	public void roll() {
		// TODO Auto-generated method stub
		System.out.println("�ѱ�Ÿ�̾�");
	}
}
