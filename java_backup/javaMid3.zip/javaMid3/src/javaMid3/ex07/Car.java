package javaMid3.ex07;

public class Car {
	
	public Tire tire;	// field ����
	
	public void run() {
		tire.roll();
	}
}