package javaMid3.ex11;

public class Parent {

}
