package javaMid3.ex03;

public class B extends BB{

	@Override
	int sum(int a) {
		// TODO Auto-generated method stub
		return super.sum(a);
	}

	void printB() {
		System.out.println(sum + " ");
	}


}
