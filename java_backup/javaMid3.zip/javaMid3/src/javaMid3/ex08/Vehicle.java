package javaMid3.ex08;

public class Vehicle {
public void run() {
	System.out.println("run");
}
}
