package javaMid3.ex08;

public class Driver {
	public void driver(Vehicle vehicle) {
		vehicle.run();
	}
}
