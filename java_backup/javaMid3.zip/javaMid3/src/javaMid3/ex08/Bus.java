package javaMid3.ex08;

public class Bus extends Vehicle {
	@Override
	public void run() {
		System.out.println("bus run");
	}

}
