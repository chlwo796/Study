package javaMid3.ex13.again;

public class KangwonJisa extends Jisa{
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "��������";
	}
}
