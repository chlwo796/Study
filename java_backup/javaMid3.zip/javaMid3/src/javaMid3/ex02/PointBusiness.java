package javaMid3.ex02;

public class PointBusiness {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Point point = new Point();
//		point.printAll();

		ColorPoint colorPoint = new ColorPoint();
		colorPoint.printAll();
	}

}
