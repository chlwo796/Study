package javaMid3.ex05;

public abstract class  B {
	abstract int bx();
	abstract boolean by();
	abstract String bs();
	abstract String bbs();
		
	
}
