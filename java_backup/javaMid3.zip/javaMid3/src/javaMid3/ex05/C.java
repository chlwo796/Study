package javaMid3.ex05;

public abstract class C {
	abstract void c1();
	abstract void c2();
}