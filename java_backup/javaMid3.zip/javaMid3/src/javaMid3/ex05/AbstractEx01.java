package javaMid3.ex05;

public class AbstractEx01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
