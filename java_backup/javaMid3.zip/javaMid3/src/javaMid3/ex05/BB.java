package javaMid3.ex05;

public class BB extends B{

	@Override
	int bx() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	boolean by() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	String bs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	String bbs() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
