package javaMid3.ex06;

public class Cat extends Animal{

}
