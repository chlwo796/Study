package javaMid3.ex12;

public class Tv extends Product{
	public Tv() {
		super(100);
	}
	
	@Override
	public String toString() {
		return "TV";
	}
}
