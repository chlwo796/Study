package javaMid3.ex12;

public class Audio extends Product {
	public Audio() {
		super(50);
	}

	@Override
	public String toString() {
		return "Audio";
	}
}
