package javaMid3.ex12;

public class Cellphone extends Product {

	public Cellphone() {
		super(150);
	}

	@Override
	public String toString() {
		return "�ڵ���";
	}
}
