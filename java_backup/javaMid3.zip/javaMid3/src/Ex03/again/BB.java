package Ex03.again;


public class BB {
   public int sum() {
	   return 0;
   }
   public int dif() {
	   return 0;
   }
}
