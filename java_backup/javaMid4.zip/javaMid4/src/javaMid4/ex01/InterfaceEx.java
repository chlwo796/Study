package javaMid4.ex01;

public class InterfaceEx {

}
