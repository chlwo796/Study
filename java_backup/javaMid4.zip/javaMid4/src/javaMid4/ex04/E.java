package javaMid4.ex04;

public class E extends C {

	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		System.out.println("E");
	}
	void printE() {
		
	}

}
