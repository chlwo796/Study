package javaMid4.ex04;

public class B implements A {
	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		System.out.println("B");

	}
}
