package javaMid4.ex04;

public class C implements A{
	void c1() {
		System.out.println("���");
	}
	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		System.out.println("C");
		
	}
	
}