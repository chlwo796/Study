package javaMid4.ex04;

public class D extends B{

}
