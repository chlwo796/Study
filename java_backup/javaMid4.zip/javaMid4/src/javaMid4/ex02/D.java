package javaMid4.ex02;

public interface D {
	boolean d1();
}
