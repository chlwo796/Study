package javaMid4.ex02;

public interface C {
	int c1();
	int c2();

}
