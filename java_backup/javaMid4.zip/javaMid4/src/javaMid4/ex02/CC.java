package javaMid4.ex02;

public interface CC extends C{
	void cc1();

}
