package javaMid4.ex03;

public class InterfaceEx03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
