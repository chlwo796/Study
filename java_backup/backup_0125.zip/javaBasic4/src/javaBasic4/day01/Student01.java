package javaBasic4.day01;

public class Student01 {

	String dep = "��ǻ���а�";
	int number = 201112488;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student01 st1 = new Student01();

		System.out.println(st1.dep + " " + st1.number);
	}
}