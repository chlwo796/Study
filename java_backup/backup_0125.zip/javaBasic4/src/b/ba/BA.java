package b.ba;

public class BA {

	private static double sd = 3.14;

	private double id = 1000.98;
	
	// getter, setter = ĸ��ȭ
	public static double getSd() {
		return sd;
	}

	public static void setSd(double sd) {
		BA.sd = sd;
	}

	public double getId() {
		return id;
	}

	public void setId(double id) {
		this.id = id;
	}
}
