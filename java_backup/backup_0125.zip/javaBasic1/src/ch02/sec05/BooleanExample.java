package ch02.sec05;

public class BooleanExample {

	public static void main(String[] args) {
		boolean a = true;
		if(a) {
			System.out.println("�����մϴ�.");
		}else {
			System.out.println("�����մϴ�.");
		}
		
		int b = 10;
		boolean result1 = b==10;
		boolean result2 = b!=10;
		
		System.out.println(result1);
		System.out.println(result2);

	}

}
