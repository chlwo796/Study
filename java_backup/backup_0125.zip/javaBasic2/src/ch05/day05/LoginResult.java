package ch05.day05;

public enum LoginResult {
	LOGIN_SUCCESS,
	LOGIN_FAILED
}
