package javaMid3.ex07;

public class KumhoTire extends Tire{
	
	@Override
	public void roll() {
		// TODO Auto-generated method stub
		System.out.println("��ȣŸ�̾�");
	}

}
