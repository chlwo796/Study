package javaMid3.ex09;

public class Person {
	public String name;
	public Person(String name) {
		this.name = name;
	}
	public void walk() {
		System.out.println("�ȱ�");
	}
}
