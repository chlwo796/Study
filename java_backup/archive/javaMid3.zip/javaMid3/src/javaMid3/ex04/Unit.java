package javaMid3.ex04;

public class Unit extends Main {
	int x;
	int y;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	void move(int x, int y) {

	}

	void stop() {
		System.out.println("���� ��ġ���� ����");
	}

}
