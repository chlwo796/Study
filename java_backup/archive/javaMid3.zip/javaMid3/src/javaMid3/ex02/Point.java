package javaMid3.ex02;

public class Point {
	int px = 1;
	int py = 2;
	
	void printAll() {
		System.out.println("(" + px + ", " + py + ")");
	}
}
