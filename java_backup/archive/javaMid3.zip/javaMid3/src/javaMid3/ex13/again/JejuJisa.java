package javaMid3.ex13.again;

public class JejuJisa extends Jisa{
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "��������";
	}
}
