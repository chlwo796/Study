package javaMid3.ex13.again;

public class Jisa {	// getter, setter
	String jisaName;	// �����
	String proName;	// ��ǰ��
	int proPrice;	// ��ǰ����
	int saleAmount;	// �Ǹŷ�
	int saleStatus; // ������Ȳ
	
	public String getJisaName() {
		return jisaName;
	}
	public void setJisaName(String jisaName) {
		this.jisaName = jisaName;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public int getProPrice() {
		return proPrice;
	}
	public void setProPrice(int proPrice) {
		this.proPrice = proPrice;
	}
	public int getSaleAmount() {
		return saleAmount;
	}
	public void setSaleAmount(int saleAmount) {
		this.saleAmount = saleAmount;
	}
	public int getSaleStatus() {
		return saleStatus;
	}
	public void setSaleStatus(int saleStatus) {
		this.saleStatus = saleStatus;
	}
}