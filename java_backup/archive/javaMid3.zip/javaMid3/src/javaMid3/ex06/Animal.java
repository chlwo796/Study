package javaMid3.ex06;

public class Animal {
	String eat() {
		return null;
	}
}
