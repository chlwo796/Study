package javaMid3.ex12;

public class Ipad extends Product {
	public Ipad() {
		super(170);
	}

	@Override
	public String toString() {
		return "�����е�";
	}
}
