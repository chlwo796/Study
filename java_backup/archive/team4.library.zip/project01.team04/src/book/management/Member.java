package book.management;

public class Member {
	
	
	public String name;
	public int lateCnt; // �ʰԳ� Ƚ��
	
	public Member(String name, int lateCnt) {
		this.name=name;
		this.lateCnt=lateCnt;
		
	}

	
	
}
