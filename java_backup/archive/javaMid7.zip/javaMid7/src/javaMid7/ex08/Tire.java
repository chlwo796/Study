package javaMid7.ex08;

public interface Tire {
	public void roll();
}
