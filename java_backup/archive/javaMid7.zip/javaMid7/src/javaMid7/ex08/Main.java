package javaMid7.ex08;

public class Main {
	public static void main(String[] args) {
		Car car1 = new Car();
		car1.tire1.roll();
		car1.tire2.roll();
	}
}
