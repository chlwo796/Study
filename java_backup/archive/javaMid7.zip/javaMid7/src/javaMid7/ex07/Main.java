package javaMid7.ex07;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
