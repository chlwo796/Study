package javaMid7.ex07;

public interface RemoteControl {
	void turnOn();
	void turnOff();
}
