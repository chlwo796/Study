package javaMid7.ex07;

public interface A {
	void abM1();
	void abM2();
}