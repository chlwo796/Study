package student.Management;

class Login {
	private static final String ID = "����id";
	private static final String PASSWORD = "123456";

	public static String getId() {
		return ID;
	}

	public static String getPassword() {
		return PASSWORD;
	}

}
