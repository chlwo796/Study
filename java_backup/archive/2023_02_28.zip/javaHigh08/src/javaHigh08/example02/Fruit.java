package javaHigh08.example02;

public class Fruit extends Chicken{
	@Override
	public void run() {
		for(int i = 0;i<100;i++) {
			System.out.println("���ϸ������");
		}

	}
}
