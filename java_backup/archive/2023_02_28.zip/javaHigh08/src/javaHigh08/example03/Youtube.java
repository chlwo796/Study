package javaHigh08.example03;

public class Youtube {

}
