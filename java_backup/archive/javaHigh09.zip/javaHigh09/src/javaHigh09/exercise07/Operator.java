package javaHigh09.exercise07;

@FunctionalInterface
public interface Operator {
	int apply(int x, int y);
}
