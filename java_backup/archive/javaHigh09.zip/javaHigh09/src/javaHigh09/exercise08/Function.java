package javaHigh09.exercise08;

@FunctionalInterface
public interface Function<T> {
	public double apply(T t);
}
