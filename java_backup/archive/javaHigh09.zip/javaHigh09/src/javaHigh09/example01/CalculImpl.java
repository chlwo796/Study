package javaHigh09.example01;

public class CalculImpl implements Calculable {
	@Override
	public void c() {
		System.out.println("Calculable�� ����");

	}
}
