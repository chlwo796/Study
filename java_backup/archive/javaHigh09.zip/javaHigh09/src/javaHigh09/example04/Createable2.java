package javaHigh09.example04;

public interface Createable2 {
	public Member create(String id, String name);
}
