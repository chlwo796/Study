package javaHigh09.example04;
@FunctionalInterface
public interface Createable1 {
public Member create(String id);
}
