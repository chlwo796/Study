package javaHigh09.example03;

public interface InterfaceEx01 {
	double c(double x, double y);
}
