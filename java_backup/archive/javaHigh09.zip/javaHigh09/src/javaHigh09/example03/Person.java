package javaHigh09.example03;

public class Person {
	public void action(InterfaceEx01 interfaceEx01) {
		double result = interfaceEx01.c(10, 4);
		System.out.println("��� : " + result);
	}
}