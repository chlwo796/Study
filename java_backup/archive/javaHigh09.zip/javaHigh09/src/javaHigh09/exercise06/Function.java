package javaHigh09.exercise06;

public interface Function {
	double apply(double x, double y);
}
