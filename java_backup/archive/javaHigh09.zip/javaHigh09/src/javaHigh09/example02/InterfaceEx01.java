package javaHigh09.example02;

public interface InterfaceEx01 {
	void cc();
}
