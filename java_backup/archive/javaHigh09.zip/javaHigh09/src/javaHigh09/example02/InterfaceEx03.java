package javaHigh09.example02;

public interface InterfaceEx03 {
	int bb(int a, int b, boolean c);
}
