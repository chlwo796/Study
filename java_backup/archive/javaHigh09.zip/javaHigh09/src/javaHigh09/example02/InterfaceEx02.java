package javaHigh09.example02;

public interface InterfaceEx02 {
	void a(int a1, double d1);
}
