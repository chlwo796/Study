package student.Management;

public class AttendanceData {
	private int status;

	public AttendanceData(int status) {
		super();
		this.status = status;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}