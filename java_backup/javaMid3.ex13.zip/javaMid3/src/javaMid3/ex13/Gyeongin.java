package javaMid3.ex13;

public class Gyeongin extends Data {

	public Gyeongin() {
		// TODO Auto-generated constructor stub
		super("��������");
	}

}
