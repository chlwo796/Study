package ch02.sec02;

public class IntegerLiteralExample {

	public static void main(String[] args) {

		int var1 = 0b1011;	//0b�� 0B = 2����
		int var2 = 0206;	//0 = 8����
		int var3 = 365;		//10����
		int var4 = 0xB3;	//0x = 16����
		
		System.out.println("var1 : " + var1);
		System.out.println("var2 : " + var2);
		System.out.println("var3 : " + var3);
		System.out.println("var4 : " + var4);
	}

}
