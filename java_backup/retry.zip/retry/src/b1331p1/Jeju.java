package b1331p1;

public class Jeju extends Company {
public Jeju() {
	super("����");
	// TODO Auto-generated constructor stub
}
}
