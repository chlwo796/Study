package b1331p1;

public class Seoul extends Company {
	public Seoul() {
		super("����");
	}
}
