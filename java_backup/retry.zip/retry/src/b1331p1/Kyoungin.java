package b1331p1;

public class Kyoungin extends Company {
public Kyoungin() {
	super("����");
	// TODO Auto-generated constructor stub
}
}
