package b1331p1;

public class Kangwon extends Company {
public Kangwon() {
	super("����");
	// TODO Auto-generated constructor stub
}
}
