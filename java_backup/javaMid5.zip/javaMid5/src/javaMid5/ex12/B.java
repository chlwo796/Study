package javaMid5.ex12;

public class B extends A {
	@Override
	public void method1() {
		System.out.println("B-method1();");
	}

}
