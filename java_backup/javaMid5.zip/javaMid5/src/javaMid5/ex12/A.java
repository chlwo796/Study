package javaMid5.ex12;

public class A {
public void method1() {
	System.out.println("A-method1();");
}
}
