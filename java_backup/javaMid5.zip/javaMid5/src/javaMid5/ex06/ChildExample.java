package javaMid5.ex06;

public class ChildExample {

//	���� 7��
	public static void main(String[] args) {
		Child child = new Child();
	}
}
