package singleton;

public class SingleTonEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Single ss = Single.getInstance();
		Single ss2 = Single.getInstance();
		
	}
}