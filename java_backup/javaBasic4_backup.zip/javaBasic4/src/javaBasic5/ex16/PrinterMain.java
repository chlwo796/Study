package javaBasic5.ex16;

public class PrinterMain {

	public static void main(String[] args) {
//		Ȯ�ι��� 16��

//		Printer printer = new Printer();
//		printer.println(10);
//		printer.println(true);
//		printer.println(5.7);
//		printer.println("ȫ�浿");

//		Ȯ�ι��� 17��
		Printer.println(10);
		Printer.println(true);
		Printer.println(5.7);
		Printer.println("ȫ�浿");

	}

}
