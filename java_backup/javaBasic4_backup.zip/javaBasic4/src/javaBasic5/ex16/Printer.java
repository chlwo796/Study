package javaBasic5.ex16;

public class Printer {

//	Ȯ�ι��� 16��
//	void println(int number) {
//		System.out.println(number);
//	}
//
//	void println(boolean result) {
//		System.out.println(result);
//	}
//
//	void println(double db) {
//		System.out.println(db);
//	}
//
//	void println(String str) {
//		System.out.println(str);
//	}

//	Ȯ�ι��� 17��
	static void println(int number) {
		System.out.println(number);
	}

	static void println(boolean result) {
		System.out.println(result);
	}

	static void println(double db) {
		System.out.println(db);
	}

	static void println(String str) {
		System.out.println(str);
	}

}
