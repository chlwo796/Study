package javaBasic5.ex19;

public class BankApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account[] account = new Account[100];
		
		System.out.println("");
		
	}

}
