package javaBasic5.ex13;

public class Member {

//		Ȯ�ι��� 13��

	String name;
	String id;
	String password;
	int age;
	
	public Member(String name, String id) {
		super();
		this.name = name;
		this.id = id;
	}
	
}
