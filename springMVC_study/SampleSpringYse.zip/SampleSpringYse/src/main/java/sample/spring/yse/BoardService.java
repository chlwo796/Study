package sample.spring.yse;

import java.util.Map;

public interface BoardService {
	public String create(Map<String, Object> map);
}