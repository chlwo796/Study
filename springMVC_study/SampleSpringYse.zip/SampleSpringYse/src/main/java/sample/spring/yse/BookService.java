package sample.spring.yse;

import java.util.Map;

public interface BookService {
	String create(Map<String, Object> map);	// 책 입력메소드
	Map<String, Object> detail(Map<String, Object> map); // 책 상세화면메소드
}