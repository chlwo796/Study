import logo from './logo.svg';
import './App.css';
import {useRef, useEffect} from "react";

const Parent = () => {
  const childFunc = useRef(null); //함수에 대한 참조를 만든다 

  return (
    <>
      <Child childFunc={childFunc} />
      <button onClick={() => childFunc.current()}>Click me</button>
    </>
  )
}

const Child = (props) => {
  useEffect(() => {
    props.childFunc.current = alertUser
  }, []);

  function alertUser() {
    alert('You clicked!')
  }

  return null
}



function App() {
  return (
    <div className="App">
      <Parent/>
    </div>
  );
}

export default App;
