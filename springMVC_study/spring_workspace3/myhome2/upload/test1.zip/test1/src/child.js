import React, {useEffect} from 'react';

function child(props) {

    const myfunc = ( )=>{
        alert("***");
    }

    useEffect = ()=>{
        
    }
    return (
        <div>
            
        </div>
    );
}

export default child;