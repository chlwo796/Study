import { memo, useEffect, useState } from "react";
import styled, { createGlobalStyle } from "styled-components";
import Item from "./item";
import Loader from "./Loader";

const GlobalStyle = createGlobalStyle`
  *, *::before, *::after {
    box-sizing: border-box;
    padding: 0px;
    margin: 0px;
  }

  body {
    background-color: #f2f5f7;
  }
`;

const AppWrap = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  align-items: center;

  .Target-Element {
    width: 100vw;
    height: 140px;
    display: flex;
    justify-content: center;
    text-align: center;
    align-items: center;
  }
`;

const Rolling = () => {
  const [target, setTarget] = useState(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [itemLists, setItemLists] = useState([1]);

  useEffect(() => {
    console.log(itemLists);
  }, [itemLists]);

  const getMoreItem = async () => {
    setIsLoaded(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));//시간 대기임  1.5초 대기 
    let Items = 
    [
        {"title":"제목1", "contents":"내용1", "writer":"홍길동1"},
        {"title":"제목2", "contents":"내용2", "writer":"홍길동2"},
        {"title":"제목3", "contents":"내용3", "writer":"홍길동3"},
        {"title":"제목4", "contents":"내용4", "writer":"홍길동4"},
        {"title":"제목5", "contents":"내용5", "writer":"홍길동5"},
        {"title":"제목6", "contents":"내용6", "writer":"홍길동6"},
        {"title":"제목7", "contents":"내용7", "writer":"홍길동7"},
        {"title":"제목8", "contents":"내용8", "writer":"홍길동8"},
        {"title":"제목9", "contents":"내용9", "writer":"홍길동9"},
        {"title":"제목10", "contents":"내용10", "writer":"홍길동10"},
    ]; 
    
    //데이터 10개씩 붙인다. 
    setItemLists((itemLists) => itemLists.concat(Items));
    setIsLoaded(false);
  };

  const onIntersect = async ([entry], observer) => {
    if (entry.isIntersecting && !isLoaded) {
      observer.unobserve(entry.target);
      await getMoreItem();
      observer.observe(entry.target);
    }
  };

  useEffect(() => {
    let observer;  //관찰자 
    if (target) {
        //onIntersect 함수 대기중 
        observer = new IntersectionObserver(onIntersect, {threshold: 0.4, });
        observer.observe(target);
    }
    return () => observer && observer.disconnect();
  }, [target  ]);

  return (
    <>
      <GlobalStyle />
      <AppWrap>
        {itemLists.map((v, i) => {
          return <Item number={i + 1} key={i} obj={v}/>;
        })}
        <div ref={setTarget} className="Target-Element">
          {isLoaded && <Loader />}
        </div>
      </AppWrap>
    </>
  );
};

export default memo(Rolling);