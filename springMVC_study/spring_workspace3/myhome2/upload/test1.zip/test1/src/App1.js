import Rolling from './Rolling';


import React from 'react';

function App1(props) {
  return (
    <div>
      <Rolling/>
    </div>
  );
}

export default App1;